using System.Collections;
using UnityEngine;

public class ModelViewer : MonoBehaviour
{
    [SerializeField] private float transitionSpeed = 5f;
    [SerializeField] private float rotationSpeed = 30f;
    [SerializeField] private float maxModelSize = 5f; // ���ģ�ͳߴ�

    private GameObject currentModel;
    private GameObject targetModel;
    private bool isTransitioning;
    private Vector3 containerCenter;

    private void Start()
    {
        // ��ȡ��������λ��
        containerCenter = transform.position;
    }

    private void OnEnable()
    {
        TimeSyncController.OnTimeChanged += UpdateModel;
    }

    private void OnDisable()
    {
        TimeSyncController.OnTimeChanged -= UpdateModel;
    }

    private void UpdateModel(string time)
    {
        DataManager dataManager = DataManager.Instance;
        if (dataManager != null && dataManager.modelPaths.ContainsKey(time))
        {
            string modelPath = dataManager.modelPaths[time];
            StartCoroutine(LoadAndTransitionModel(modelPath));
        }
    }

    private IEnumerator LoadAndTransitionModel(string path)
    {
        // ������ģ��
        GameObject newModel = OBJLoader.LoadOBJFile(path);
        if (newModel == null) yield break;

        // Ӧ�û���������
        ApplyConcreteMaterial(newModel);

        newModel.transform.SetParent(transform);
        newModel.SetActive(false);

        // ����ģ�Ͱ�Χ��
        Bounds bounds = CalculateBounds(newModel);
        Vector3 center = bounds.center;
        float maxExtent = Mathf.Max(bounds.extents.x, bounds.extents.y, bounds.extents.z);
        float scale = maxModelSize / (2 * maxExtent);

        // ��ʼ����
        targetModel = newModel;
        isTransitioning = true;

        // ������ǰģ��
        if (currentModel != null)
        {
            Vector3 startPos = currentModel.transform.position;
            Vector3 endPos = startPos + new Vector3(2, 0, 0); // �����Ƴ�

            float t = 0;
            while (t < 1)
            {
                t += Time.deltaTime * transitionSpeed;
                currentModel.transform.position = Vector3.Lerp(startPos, endPos, t);
                yield return null;
            }

            Destroy(currentModel);
        }

        // ������ģ��
        targetModel.SetActive(true);
        // ������ģ�͵�λ�ú�����
        targetModel.transform.localScale = Vector3.one * scale;
        // ��ģ�������ƶ�����������
        targetModel.transform.position = containerCenter - center * scale;

        // ��ʼλ�ã��������룩
        Vector3 startPosition = containerCenter - center * scale + new Vector3(-2, 0, 0);
        targetModel.transform.position = startPosition;

        float transitionTime = 0;
        while (transitionTime < 1)
        {
            transitionTime += Time.deltaTime * transitionSpeed;
            targetModel.transform.position = Vector3.Lerp(startPosition, containerCenter - center * scale, transitionTime);
            yield return null;
        }

        currentModel = targetModel;
        targetModel = null;
        isTransitioning = false;
    }

    private Bounds CalculateBounds(GameObject obj)
    {
        Renderer[] renderers = obj.GetComponentsInChildren<Renderer>();
        if (renderers.Length == 0) return new Bounds();

        Bounds bounds = renderers[0].bounds;
        foreach (Renderer r in renderers)
        {
            bounds.Encapsulate(r.bounds);
        }
        return bounds;
    }

    private void ApplyConcreteMaterial(GameObject model)
    {
        // ��������������
        Material concreteMaterial = new Material(Shader.Find("Standard"));
        concreteMaterial.name = "Concrete_Material";

        // ���û���������������
        concreteMaterial.SetFloat("_Glossiness", 0.2f); // �͹����
        concreteMaterial.SetFloat("_Metallic", 0.1f); // �ͽ�����

        // ���ػ���������������У�
        Texture2D concreteTexture = Resources.Load<Texture2D>("Textures/concrete");
        if (concreteTexture != null)
        {
            concreteMaterial.mainTexture = concreteTexture;
        }

        // Ӧ�ò��ʵ������Ӷ���
        Renderer[] renderers = model.GetComponentsInChildren<Renderer>();
        foreach (Renderer renderer in renderers)
        {
            renderer.material = concreteMaterial;
        }
    }

    private void Update()
    {
        if (currentModel != null && !isTransitioning)
        {
            // ģ��Χ������������ת
            currentModel.transform.RotateAround(containerCenter, Vector3.up, rotationSpeed * Time.deltaTime);
        }
    }
}