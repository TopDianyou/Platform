// UIManager.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    [Header("UI Elements")]
    [SerializeField] private Text currentTimeText;
    [SerializeField] private Slider timelineSlider;
    [SerializeField] private Button playButton;
    [SerializeField] private Button pauseButton;
    [SerializeField] private Button prevButton;
    [SerializeField] private Button nextButton;

    [Header("Charts")]
    [SerializeField] private DamageChartXCharts registrationChart;
    [SerializeField] private DamageChartXCharts temporalChart;

    private TimeSyncController timeController;
    private bool isPlaying = false;

    private void Start()
    {
        timeController = FindObjectOfType<TimeSyncController>();
        if (timeController == null)
        {
            Debug.LogError("TimeSyncController not found in scene.");
            return;
        }

        timelineSlider.minValue = 0;
        
        timelineSlider.wholeNumbers = true;

        timelineSlider.onValueChanged.AddListener(OnTimelineChanged);
        playButton.onClick.AddListener(OnPlayClicked);
        pauseButton.onClick.AddListener(OnPauseClicked);
        prevButton.onClick.AddListener(OnPrevClicked);
        nextButton.onClick.AddListener(OnNextClicked);

        DataManager dataManager = DataManager.Instance;
        if (dataManager != null)
        {
            if (dataManager.registrationDamage != null && registrationChart != null)
            {
                registrationChart.Initialize(dataManager.registrationDamage, "Registration Damage");
            }

            if (dataManager.temporalDamage != null && temporalChart != null)
            {
                temporalChart.Initialize(dataManager.temporalDamage, "Temporal Damage");
            }
        }

        UpdateTimeDisplay();
    }

    private void OnEnable()
    {
        TimeSyncController.OnTimeChanged += OnTimeChanged;
    }

    private void OnDisable()
    {
        TimeSyncController.OnTimeChanged -= OnTimeChanged;
    }

    private void OnTimeChanged(string time)
    {
        UpdateTimeDisplay();

        // ���ڷǲ���״̬�¸���ͼ��
        if (!isPlaying && timeController != null)
        {
            if (registrationChart != null) registrationChart.HighlightTime(time);
            if (temporalChart != null) temporalChart.HighlightTime(time);
        }

        if (timeController != null)
        {
            timelineSlider.SetValueWithoutNotify(timeController.GetCurrentIndex());
        }
    }

    private void UpdateTimeDisplay()
    {
        if (timeController != null && currentTimeText != null)
        {
            string currentTime = timeController.GetCurrentTime();
            int index = timeController.GetCurrentIndex();
            int total = timeController.GetAllTimes().Count;

            currentTimeText.text = $"<size=36>Time: {currentTime}s</size>\n<size=24>({index + 1}/{total})</size>";
        }
    }

    private void OnTimelineChanged(float value)
    {
        if (timeController != null)
        {
            List<string> times = timeController.GetAllTimes();
            if (times.Count > 0)
            {
                int index = Mathf.Clamp((int)value, 0, times.Count - 1);
                timeController.SetCurrentTime(times[index]);
            }
        }
    }

    private void OnPlayClicked()
    {
        if (timeController != null)
        {
            isPlaying = true;
            timeController.EnableChartRefresh(false); // ����ͼ��ˢ��
            timeController.PlaySequence(0.5f);
        }
    }

    private void OnPauseClicked()
    {
        if (timeController != null)
        {
            isPlaying = false;
            timeController.EnableChartRefresh(true); // ����ͼ��ˢ��
            timeController.StopAllCoroutines();
        }
    }

    private void OnPrevClicked()
    {
        if (timeController != null)
        {
            timeController.PreviousTime();
        }
    }

    private void OnNextClicked()
    {
        if (timeController != null)
        {
            timeController.NextTime();
        }
    }
}