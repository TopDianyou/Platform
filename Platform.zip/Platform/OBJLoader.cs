using System.Collections.Generic;
using System.IO;
using UnityEngine;

public static class OBJLoader
{
    public static GameObject LoadOBJFile(string filePath)
    {
        if (!File.Exists(filePath))
        {
            Debug.LogError("OBJ file not found: " + filePath);
            return null;
        }

        try
        {
            // ʹ���µ�OBJ������
            var loader = new OBJLoaderWithMaterials();
            var obj = loader.Load(filePath);
            obj.name = Path.GetFileNameWithoutExtension(filePath);
            return obj;
        }
        catch (System.Exception e)
        {
            Debug.LogError("Error loading OBJ: " + e.Message);
            return null;
        }
    }
}

public class OBJLoaderWithMaterials
{
    public GameObject Load(string filePath)
    {
        if (!File.Exists(filePath))
            return null;

        string materialPath = Path.ChangeExtension(filePath, ".mtl");
        Dictionary<string, Material> materials = null;

        if (File.Exists(materialPath))
        {
            materials = LoadMaterials(materialPath);
        }

        return ParseOBJ(filePath, materials);
    }

    private Dictionary<string, Material> LoadMaterials(string mtlPath)
    {
        Dictionary<string, Material> materials = new();
        string currentMaterial = null;

        foreach (string line in File.ReadAllLines(mtlPath))
        {
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                continue;

            string[] parts = line.Split(new char[] { ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) continue;

            switch (parts[0])
            {
                case "newmtl":
                    currentMaterial = parts[1];
                    materials[currentMaterial] = new Material(Shader.Find("Standard"));
                    break;

                case "Kd":
                    if (currentMaterial != null && parts.Length >= 4)
                    {
                        Color color = new(
                            float.Parse(parts[1]),
                            float.Parse(parts[2]),
                            float.Parse(parts[3]));
                        materials[currentMaterial].color = color;
                    }
                    break;

                case "map_Kd":
                    if (currentMaterial != null)
                    {
                        string texturePath = Path.Combine(Path.GetDirectoryName(mtlPath), parts[1]);
                        if (File.Exists(texturePath))
                        {
                            Texture2D tex = new(2, 2);
                            tex.LoadImage(File.ReadAllBytes(texturePath));
                            materials[currentMaterial].mainTexture = tex;
                        }
                    }
                    break;
            }
        }

        return materials;
    }

    private GameObject ParseOBJ(string objPath, Dictionary<string, Material> materials)
    {
        List<Vector3> vertices = new();
        List<Vector2> uvs = new();
        List<Vector3> normals = new();
        string currentMaterial = null;

        GameObject root = new(Path.GetFileNameWithoutExtension(objPath));
        MeshRenderer renderer = root.AddComponent<MeshRenderer>();
        MeshFilter filter = root.AddComponent<MeshFilter>();
        Mesh mesh = new();

        List<Material> usedMaterials = new();
        Dictionary<string, List<int>> materialTriangles = new();

        List<int> allTriangles = new();

        foreach (string line in File.ReadAllLines(objPath))
        {
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                continue;

            string[] parts = line.Split(new char[] { ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) continue;

            switch (parts[0])
            {
                case "v": // ����
                    if (parts.Length >= 4)
                    {
                        vertices.Add(new Vector3(
                            float.Parse(parts[1]),
                            float.Parse(parts[2]),
                            float.Parse(parts[3])));
                    }
                    break;

                case "vt": // UV
                    if (parts.Length >= 3)
                    {
                        uvs.Add(new Vector2(
                            float.Parse(parts[1]),
                            float.Parse(parts[2])));
                    }
                    break;

                case "vn": // ����
                    if (parts.Length >= 4)
                    {
                        normals.Add(new Vector3(
                            float.Parse(parts[1]),
                            float.Parse(parts[2]),
                            float.Parse(parts[3])).normalized);
                    }
                    break;

                case "usemtl": // ����
                    currentMaterial = parts[1];
                    if (materials != null && materials.ContainsKey(currentMaterial))
                    {
                        if (!materialTriangles.ContainsKey(currentMaterial))
                        {
                            materialTriangles[currentMaterial] = new List<int>();
                            usedMaterials.Add(materials[currentMaterial]);
                        }
                    }
                    break;

                case "f": // ��
                    List<int> faceVertices = new();
                    List<int> faceUVs = new();
                    List<int> faceNormals = new();

                    for (int i = 1; i < parts.Length; i++)
                    {
                        string[] indices = parts[i].Split('/');
                        if (indices.Length >= 1)
                        {
                            faceVertices.Add(int.Parse(indices[0]) - 1);

                            if (indices.Length > 1 && !string.IsNullOrEmpty(indices[1]))
                                faceUVs.Add(int.Parse(indices[1]) - 1);

                            if (indices.Length > 2 && !string.IsNullOrEmpty(indices[2]))
                                faceNormals.Add(int.Parse(indices[2]) - 1);
                        }
                    }

                    // ���ǻ��������
                    for (int i = 1; i < faceVertices.Count - 1; i++)
                    {
                        int v1 = faceVertices[0];
                        int v2 = faceVertices[i];
                        int v3 = faceVertices[i + 1];

                        if (currentMaterial != null && materialTriangles.ContainsKey(currentMaterial))
                        {
                            materialTriangles[currentMaterial].Add(v1);
                            materialTriangles[currentMaterial].Add(v2);
                            materialTriangles[currentMaterial].Add(v3);
                        }

                        allTriangles.Add(v1);
                        allTriangles.Add(v2);
                        allTriangles.Add(v3);
                    }
                    break;
            }
        }

        // ������������
        mesh.vertices = vertices.ToArray();

        // ����UV������У�
        if (uvs.Count > 0 && uvs.Count == vertices.Count)
        {
            mesh.uv = uvs.ToArray();
        }

        // ����������
        if (materialTriangles.Count > 0)
        {
            mesh.subMeshCount = usedMaterials.Count;
            int submeshIndex = 0;

            foreach (var material in usedMaterials)
            {
                string matName = material.name;
                if (materialTriangles.ContainsKey(matName))
                {
                    mesh.SetTriangles(materialTriangles[matName], submeshIndex);
                    submeshIndex++;
                }
            }

            renderer.materials = usedMaterials.ToArray();
        }
        else
        {
            // ʹ�õ�һ����
            mesh.triangles = allTriangles.ToArray();
            renderer.material = new Material(Shader.Find("Standard"));
        }

        // �Զ����㷨�ߺͱ߽�
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        mesh.RecalculateTangents();

        filter.mesh = mesh;

        return root;
    }
}