using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Linq;

public class DamageChart : MonoBehaviour
{
    [SerializeField] private RectTransform chartContainer;
    [SerializeField] private GameObject pointPrefab;
    [SerializeField] private GameObject linePrefab;
    [SerializeField] private GameObject axisLabelPrefab; // �������ǩԤ����
    [SerializeField] private Color lineColor = Color.red;
    [SerializeField] private Color highlightColor = Color.yellow;
    [SerializeField] private GameObject tooltipPrefab;

    private readonly Dictionary<string, GameObject> dataPoints = new();
    private Dictionary<string, float> damageData;

    public void Initialize(Dictionary<string, float> data)
    {
        if (data == null || data.Count == 0)
        {
            Debug.LogError("DamageChart: No data provided for initialization");
            return;
        }

        damageData = data;
        CreateChart();
    }

    private void CreateChart()
    {
        // ��������ͼ��
        foreach (Transform child in chartContainer)
        {
            Destroy(child.gameObject);
        }
        dataPoints.Clear();

        if (damageData == null || damageData.Count == 0)
        {
            Debug.LogWarning("DamageChart: No damage data available for chart");
            return;
        }

        // ��ȡ������ʱ���
        List<string> sortedTimes = DataManager.Instance.timePoints;

        if (sortedTimes == null || sortedTimes.Count == 0)
        {
            Debug.LogError("DamageChart: No time points available");
            return;
        }

        // ����ͼ���ߴ�
        float maxValue = damageData.Values.Max();
        float minValue = damageData.Values.Min();
        float valueRange = Mathf.Max(0.1f, maxValue - minValue);

        float chartWidth = chartContainer.rect.width - 40; // ������ߺ��ұߵĿռ�
        float chartHeight = chartContainer.rect.height - 40; // �����ϱߺ��±ߵĿռ�
        float xStep = chartWidth / (sortedTimes.Count - 1);

        // ����������
        DrawAxes(chartWidth, chartHeight, minValue, maxValue);

        // �������ݵ������
        Vector2? previousPoint = null;

        for (int i = 0; i < sortedTimes.Count; i++)
        {
            string time = sortedTimes[i];
            if (!damageData.ContainsKey(time))
            {
                Debug.LogWarning($"DamageChart: No damage data for time {time}");
                continue;
            }

            float value = damageData[time];
            // ��һ����ͼ������ע�⣺���½�Ϊԭ�㣩
            float yPos = ((value - minValue) / valueRange) * chartHeight;
            float xPos = i * xStep;

            // �������ݵ㣨��chartContainer�ڣ�ע��ƫ�ƣ�
            if (pointPrefab == null)
            {
                Debug.LogError("DamageChart: Point prefab is not assigned");
                return;
            }

            GameObject point = Instantiate(pointPrefab, chartContainer);
            RectTransform pointRect = point.GetComponent<RectTransform>();
            pointRect.anchoredPosition = new Vector2(xPos + 20, yPos + 20); // ƫ��20���أ������������ռ�

            // ���ӵ���¼�
            Button pointButton = point.GetComponent<Button>();
            if (pointButton != null)
            {
                pointButton.onClick.AddListener(() => OnPointClick(time));
            }

            // ������ͣ��ʾ
            var tooltip = point.AddComponent<DamageTooltip>();
            tooltip.tooltipPrefab = tooltipPrefab;
            tooltip.SetDamageValue(value);

            dataPoints.Add(time, point);

            // ��������
            if (previousPoint != null && linePrefab != null)
            {
                GameObject line = Instantiate(linePrefab, chartContainer);
                RectTransform lineRect = line.GetComponent<RectTransform>();

                Vector2 currentPoint = new Vector2(xPos + 20, yPos + 20);
                Vector2 dir = currentPoint - previousPoint.Value;
                float distance = dir.magnitude;
                float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

                lineRect.sizeDelta = new Vector2(distance, 2f);
                lineRect.anchoredPosition = previousPoint.Value + dir / 2f;
                lineRect.localEulerAngles = new Vector3(0, 0, angle);

                Image lineImage = line.GetComponent<Image>();
                if (lineImage != null)
                {
                    lineImage.color = lineColor;
                }
            }

            previousPoint = new Vector2(xPos + 20, yPos + 20);
        }

        Debug.Log($"DamageChart: Created chart with {dataPoints.Count} points");
    }

    private void DrawAxes(float width, float height, float minValue, float maxValue)
    {
        // ����X��
        GameObject xAxis = new GameObject("XAxis", typeof(Image));
        xAxis.transform.SetParent(chartContainer, false);
        RectTransform xRect = xAxis.GetComponent<RectTransform>();
        xRect.anchorMin = new Vector2(0, 0);
        xRect.anchorMax = new Vector2(0, 0);
        xRect.pivot = new Vector2(0, 0);
        xRect.anchoredPosition = new Vector2(20, 20);
        xRect.sizeDelta = new Vector2(width, 2);
        xAxis.GetComponent<Image>().color = Color.black;

        // ����Y��
        GameObject yAxis = new GameObject("YAxis", typeof(Image));
        yAxis.transform.SetParent(chartContainer, false);
        RectTransform yRect = yAxis.GetComponent<RectTransform>();
        yRect.anchorMin = new Vector2(0, 0);
        yRect.anchorMax = new Vector2(0, 0);
        yRect.pivot = new Vector2(0, 0);
        yRect.anchoredPosition = new Vector2(20, 20);
        yRect.sizeDelta = new Vector2(2, height);
        yAxis.GetComponent<Image>().color = Color.black;

        // ����X���ǩ��ʱ��㣩
        for (int i = 0; i < DataManager.Instance.timePoints.Count; i += 5) // ÿ��5������ʾһ����ǩ
        {
            if (i < DataManager.Instance.timePoints.Count)
            {
                string time = DataManager.Instance.timePoints[i];
                GameObject label = Instantiate(axisLabelPrefab, chartContainer);
                label.GetComponent<Text>().text = time;
                label.GetComponent<Text>().fontSize = 24;
                RectTransform labelRect = label.GetComponent<RectTransform>();
                labelRect.anchorMin = new Vector2(0, 0);
                labelRect.anchorMax = new Vector2(0, 0);
                labelRect.pivot = new Vector2(0.5f, 0);
                float xPos = (i / (float)(DataManager.Instance.timePoints.Count - 1)) * width + 20;
                labelRect.anchoredPosition = new Vector2(xPos, 0);
            }
        }

        // ����Y���ǩ
        for (int i = 0; i <= 5; i++)
        {
            GameObject label = Instantiate(axisLabelPrefab, chartContainer);
            label.GetComponent<Text>().fontSize = 24;
            RectTransform labelRect = label.GetComponent<RectTransform>();
            labelRect.anchorMin = new Vector2(0, 0);
            labelRect.anchorMax = new Vector2(0, 0);
            labelRect.pivot = new Vector2(1, 0.5f);

            float normalizedValue = i / 5f;
            float value = minValue + normalizedValue * (maxValue - minValue);
            float yPos = normalizedValue * height + 20;

            labelRect.anchoredPosition = new Vector2(15, yPos);
            label.GetComponent<Text>().text = value.ToString("F2");
        }

        // ����X�����
        GameObject xTitle = new GameObject("XTitle", typeof(Text));
        xTitle.transform.SetParent(chartContainer, false);
        Text xText = xTitle.GetComponent<Text>();
        xText.text = "Time (s)";
        xText.fontSize = 24;
        xText.alignment = TextAnchor.MiddleCenter;
        RectTransform xTitleRect = xTitle.GetComponent<RectTransform>();
        xTitleRect.anchorMin = new Vector2(0, 0);
        xTitleRect.anchorMax = new Vector2(0, 0);
        xTitleRect.pivot = new Vector2(0.5f, 0);
        xTitleRect.anchoredPosition = new Vector2(20 + width / 2, 0);
        xTitleRect.sizeDelta = new Vector2(100, 30);

        // ����Y�����
        GameObject yTitle = new GameObject("YTitle", typeof(Text));
        yTitle.transform.SetParent(chartContainer, false);
        Text yText = yTitle.GetComponent<Text>();
        yText.text = "Damage";
        yText.fontSize = 24;
        yText.alignment = TextAnchor.MiddleCenter;
        RectTransform yTitleRect = yTitle.GetComponent<RectTransform>();
        yTitleRect.anchorMin = new Vector2(0, 0);
        yTitleRect.anchorMax = new Vector2(0, 0);
        yTitleRect.pivot = new Vector2(0.5f, 0.5f);
        yTitleRect.anchoredPosition = new Vector2(0, 20 + height / 2);
        yTitleRect.sizeDelta = new Vector2(100, 30);
        yTitleRect.rotation = Quaternion.Euler(0, 0, -90); // ��ת90��
    }

    private void OnPointClick(string time)
    {
        TimeSyncController timeController = FindObjectOfType<TimeSyncController>();
        if (timeController != null)
        {
            timeController.SetCurrentTime(time);
        }
    }

    public void HighlightTime(string time)
    {
        foreach (var point in dataPoints)
        {
            Image img = point.Value.GetComponent<Image>();
            if (img != null)
            {
                img.color = point.Key == time ? highlightColor : Color.white;
            }
        }
    }
}

public class DamageTooltip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public GameObject tooltipPrefab;
    private GameObject tooltipInstance;
    private Canvas canvas;
    private float damageValue;

    private void Start()
    {
        canvas = FindObjectOfType<Canvas>();
    }

    public void SetDamageValue(float value)
    {
        damageValue = value;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (tooltipPrefab == null || canvas == null) return;

        if (tooltipInstance == null)
        {
            tooltipInstance = Instantiate(tooltipPrefab, canvas.transform);
            Text tooltipText = tooltipInstance.GetComponentInChildren<Text>();
            if (tooltipText != null)
            {
                tooltipText.text = damageValue.ToString("F4");
                tooltipText.fontSize = 24;
            }
        }

        tooltipInstance.transform.position = transform.position + new Vector3(0, 50, 0);
        tooltipInstance.SetActive(true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (tooltipInstance != null)
        {
            tooltipInstance.SetActive(false);
        }
    }

    private void OnDestroy()
    {
        if (tooltipInstance != null)
        {
            Destroy(tooltipInstance);
        }
    }
}