// RegistrationViewer.cs (SegmentationViewer.csҲ��ͬ���޸�)
using UnityEngine;
using UnityEngine.UI;

public class RegistrationViewer : MonoBehaviour
{
    [SerializeField] private RawImage displayImage;

    private void OnEnable()
    {
        TimeSyncController.OnTimeChanged += UpdateRegistrationDisplay;
    }

    private void OnDisable()
    {
        TimeSyncController.OnTimeChanged -= UpdateRegistrationDisplay;
    }

    private void UpdateRegistrationDisplay(string time)
    {
        // ���ӿռ������쳣
        if (displayImage == null) return;

        DataManager dataManager = DataManager.Instance;
        if (dataManager != null && dataManager.registrationResults.ContainsKey(time))
        {
            displayImage.texture = dataManager.registrationResults[time];

            // ǿ��ˢ��ͼ����ʾ
            displayImage.enabled = false;
            displayImage.enabled = true;
        }
    }

    public void OnImageClick()
    {
        string currentTime = FindObjectOfType<TimeSyncController>().GetCurrentTime();
        FindObjectOfType<TimeSyncController>().SetCurrentTime(currentTime);
    }
}