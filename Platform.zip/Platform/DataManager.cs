using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System;
using System.Linq;

public class DataManager : MonoBehaviour
{
    public static DataManager Instance { get; private set; }

    public List<string> timePoints = new();
    public Dictionary<string, Texture2D> segmentationResults = new();
    public Dictionary<string, Texture2D> registrationResults = new(); // ������׼���
    public Dictionary<string, float> registrationDamage = new();
    public Dictionary<string, float> temporalDamage = new();
    public Dictionary<string, string> modelPaths = new();
    public Dictionary<string, string> timeToIndexMap = new();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            LoadAllData();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void LoadAllData()
    {
        Debug.Log("Loading all data...");

        // ����ʱ���
        string timeFilePath = Path.Combine(Application.dataPath, "Data/time.txt");
        if (File.Exists(timeFilePath))
        {
            string[] times = File.ReadAllLines(timeFilePath);
            timePoints.AddRange(times);
            Debug.Log($"Loaded {timePoints.Count} time points from {timeFilePath}");
        }
        else
        {
            Debug.LogError("Time file not found: " + timeFilePath);
        }

        // ����ʱ��㵽������ӳ��
        for (int i = 0; i < timePoints.Count; i++)
        {
            string index = i.ToString("D6"); // ��ʽ��Ϊ6λ����
            timeToIndexMap[timePoints[i]] = index;
        }

        // ��������ָ���
        foreach (var time in timePoints)
        {
            string index = timeToIndexMap[time];
            string segPath = Path.Combine("SegmentationResults", $"{index}_seg");
            Texture2D segTexture = Resources.Load<Texture2D>(segPath);
            if (segTexture != null)
            {
                segmentationResults.Add(time, segTexture);
            }
            else
            {
                Debug.LogWarning($"Segmentation texture not found: {index}_seg");
            }
        }
        Debug.Log($"Loaded {segmentationResults.Count} segmentation results");

        // ������������׼���
        foreach (var time in timePoints)
        {
            string index = timeToIndexMap[time];
            string regPath = Path.Combine("RegistrationResults", $"{index}_reg");
            Texture2D regTexture = Resources.Load<Texture2D>(regPath);
            if (regTexture != null)
            {
                registrationResults.Add(time, regTexture);
            }
            else
            {
                Debug.LogWarning($"Registration texture not found: {index}_reg");
            }
        }
        Debug.Log($"Loaded {registrationResults.Count} registration results");

        // ��������Ԥ����
        TextAsset regDamageJson = Resources.Load<TextAsset>("DamageResults/registration_damage");
        if (regDamageJson != null)
        {
            ParseDamageData(regDamageJson.text, registrationDamage);
            Debug.Log($"Loaded {registrationDamage.Count} registration damage points");
        }
        else
        {
            Debug.LogError("Registration damage JSON not found");
        }

        TextAsset tempDamageJson = Resources.Load<TextAsset>("DamageResults/temporal_damage");
        if (tempDamageJson != null)
        {
            ParseDamageData(tempDamageJson.text, temporalDamage);
            Debug.Log($"Loaded {temporalDamage.Count} temporal damage points");
        }
        else
        {
            Debug.LogError("Temporal damage JSON not found");
        }

        // ӳ��OBJģ��·��
        foreach (var time in timePoints)
        {
            string index = timeToIndexMap[time];
            string modelFolder = Path.Combine(Application.dataPath, $"Data/OBJ_Models/{index}");
            if (Directory.Exists(modelFolder))
            {
                string[] objFiles = Directory.GetFiles(modelFolder, "*.obj");
                if (objFiles.Length > 0)
                {
                    // ���Ȳ���3d.obj������ȡ��һ��
                    string objPath = objFiles.FirstOrDefault(f => f.EndsWith("3d.obj")) ?? objFiles[0];
                    modelPaths.Add(time, objPath);
                }
                else
                {
                    Debug.LogWarning($"No OBJ files found in: {modelFolder}");
                }
            }
            else
            {
                Debug.LogWarning($"Model folder not found: {modelFolder}");
            }
        }
        Debug.Log($"Mapped {modelPaths.Count} model paths");
    }

    private void ParseDamageData(string jsonText, Dictionary<string, float> targetDict)
    {
        try
        {
            // ʹ��Unity��JsonUtility��������
            DamageData data = JsonUtility.FromJson<DamageData>(jsonText);

            if (data != null && data.values != null)
            {
                foreach (var item in data.values)
                {
                    if (timePoints.Contains(item.time))
                    {
                        targetDict[item.time] = item.value;
                    }
                    else
                    {
                        Debug.LogWarning($"Time point {item.time} not found in time.txt");
                    }
                }
            }
            else
            {
                Debug.LogError("Failed to parse damage data: JSON format invalid");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"Error parsing JSON: {e.Message}\n{jsonText}");
        }
    }

    [System.Serializable]
    public class DamageData
    {
        public List<DamageItem> values;
    }

    [System.Serializable]
    public class DamageItem
    {
        public string time;
        public float value;
    }
}


