// TimeSyncController.cs
using System;
using System.Collections.Generic;
using UnityEngine;

public class TimeSyncController : MonoBehaviour
{
    public static event Action<string> OnTimeChanged;

    [SerializeField] private List<string> timePoints = new();
    private int currentIndex = 0;
    private bool isChartRefreshEnabled = true; // ����ͼ��ˢ�¿��Ʊ�־

    public void EnableChartRefresh(bool enable) => isChartRefreshEnabled = enable;

    private void Start()
    {
        DataManager dataManager = FindObjectOfType<DataManager>();
        if (dataManager != null && dataManager.timePoints.Count > 0)
        {
            timePoints = dataManager.timePoints;
            SetCurrentTime(timePoints[0]);
        }
    }

    public void SetCurrentTime(string time)
    {
        if (timePoints.Contains(time))
        {
            currentIndex = timePoints.IndexOf(time);
            OnTimeChanged?.Invoke(time);
        }
    }

    public void NextTime()
    {
        if (currentIndex < timePoints.Count - 1)
        {
            currentIndex++;
            SetCurrentTime(timePoints[currentIndex]);
        }
    }

    public void PreviousTime()
    {
        if (currentIndex > 0)
        {
            currentIndex--;
            SetCurrentTime(timePoints[currentIndex]);
        }
    }

    public void PlaySequence(float interval = 1.0f)
    {
        StopAllCoroutines();
        StartCoroutine(PlaySequenceCoroutine(interval));
    }

    private System.Collections.IEnumerator PlaySequenceCoroutine(float interval)
    {
        while (currentIndex < timePoints.Count - 1)
        {
            yield return new WaitForSeconds(interval);
            NextTime();
        }
    }

    public string GetCurrentTime()
    {
        if (currentIndex >= 0 && currentIndex < timePoints.Count)
        {
            return timePoints[currentIndex];
        }
        return "";
    }

    public int GetCurrentIndex()
    {
        return currentIndex;
    }

    public List<string> GetAllTimes()
    {
        return timePoints;
    }
}