using UnityEngine;
using UnityEngine.UI;

public class SegmentationViewer : MonoBehaviour
{
    [SerializeField] private RawImage displayImage;

    private void OnEnable()
    {
        TimeSyncController.OnTimeChanged += UpdateSegmentationDisplay;
    }

    private void OnDisable()
    {
        TimeSyncController.OnTimeChanged -= UpdateSegmentationDisplay;
    }

    private void UpdateSegmentationDisplay(string time)
    {
        DataManager dataManager = DataManager.Instance;
        if (dataManager != null && dataManager.segmentationResults.ContainsKey(time))
        {
            displayImage.texture = dataManager.segmentationResults[time];
        }
    }

    public void OnImageClick()
    {
        // �����ͼ��ʱ��֪ͨʱ�����������ʱ��
        string currentTime = FindObjectOfType<TimeSyncController>().GetCurrentTime();
        FindObjectOfType<TimeSyncController>().SetCurrentTime(currentTime);
    }
}