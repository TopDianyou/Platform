using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XCharts.Runtime;

public class DamageChartXCharts : MonoBehaviour
{
    [SerializeField] private LineChart chart;
    [SerializeField] private string chartName;
    [SerializeField] private Color lineColor = Color.red;
    [SerializeField] private Color pointColor = Color.blue;
    [SerializeField] private float lineWidth = 2f;
    [SerializeField] private float pointSize = 5f;

    private Dictionary<string, int> timeToIndexMap = new Dictionary<string, int>();
    private Dictionary<string, float> damageData;
    private Serie serie;
    private int lastHighlightedIndex = -1;

    private void Start()
    {
        InitializeChart();
    }

    public void Initialize(Dictionary<string, float> data, string title)
    {
        damageData = data;
        chartName = title;

        if (chart != null)
        {
            chart.ClearData();

            // ����Y���ʽΪС�����1λ
            var yAxis = chart.GetChartComponent<YAxis>();
            if (yAxis != null)
            {
                yAxis.axisLabel.formatter = "{value:f1}"; // f1��ʾ1λС��
            }

            serie = chart.AddSerie<Line>("Damage");
            serie.symbol.show = true;
            serie.symbol.size = pointSize;
            serie.lineStyle.width = lineWidth;
            serie.lineStyle.color = lineColor;
            serie.itemStyle.color = pointColor;
            serie.animation.enable = false;

            AddDataPoints();
        }
    }

    private void AddDataPoints()
    {
        if (damageData == null) return;

        timeToIndexMap.Clear();
        List<string> times = DataManager.Instance.timePoints;

        for (int i = 0; i < times.Count; i++)
        {
            string time = times[i];
            if (damageData.ContainsKey(time))
            {
                float value = damageData[time];
                chart.AddData(serie.index, value, time);
                timeToIndexMap[time] = i;
            }
        }
    }

    public void HighlightTime(string time)
    {
        if (serie == null || !timeToIndexMap.ContainsKey(time)) return;

        int index = timeToIndexMap[time];
        if (lastHighlightedIndex == index) return;

        StartCoroutine(HighlightPointCoroutine(index));
    }

    private System.Collections.IEnumerator HighlightPointCoroutine(int index)
    {
        yield return null;

        if (lastHighlightedIndex >= 0 && lastHighlightedIndex < serie.dataCount)
        {
            serie.data[lastHighlightedIndex].itemStyle.color = pointColor;
        }

        if (index >= 0 && index < serie.dataCount)
        {
            serie.data[index].itemStyle.color = Color.yellow;
            chart.RefreshChart();
        }

        lastHighlightedIndex = index;
    }

    private void InitializeChart()
    {
        if (chart != null)
        {
            chart.ClearData();
        }
    }
}